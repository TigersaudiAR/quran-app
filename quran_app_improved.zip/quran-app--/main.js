
// إعدادات التطبيق
const APP_CONFIG = {
    version: '1.1.0',
    name: 'تطبيق القرآن الكريم التعليمي',
    developer: 'تحسين بواسطة ChatGPT',
    apiUrl: 'https://api.quran.com/api/v4/',
};

// حالة التطبيق
const appState = {
    isLoading: true,
    currentSurah: 1,
    currentAyah: 1,
    surahList: [],
};

// تحميل قائمة السور من API
async function fetchSurahList() {
    try {
        const response = await fetch(APP_CONFIG.apiUrl + 'chapters');
        const data = await response.json();
        appState.surahList = data.chapters;
        renderSurahList();
    } catch (error) {
        console.error('حدث خطأ أثناء تحميل السور:', error);
    }
}

// عرض قائمة السور في الصفحة
function renderSurahList() {
    const surahContainer = document.getElementById('surah-list');
    surahContainer.innerHTML = '';
    
    appState.surahList.forEach(surah => {
        const surahItem = document.createElement('div');
        surahItem.classList.add('surah-item');
        surahItem.textContent = `${surah.id}. ${surah.name_arabic} (${surah.verses_count} آية)`;
        surahItem.onclick = () => fetchSurahContent(surah.id);
        surahContainer.appendChild(surahItem);
    });
}

// تحميل محتوى السورة من API
async function fetchSurahContent(surahId) {
    try {
        const response = await fetch(`${APP_CONFIG.apiUrl}quran/verses/uthmani?chapter_number=${surahId}`);
        const data = await response.json();
        renderSurahContent(data.verses);
    } catch (error) {
        console.error('حدث خطأ أثناء تحميل الآيات:', error);
    }
}

// عرض محتوى السورة
function renderSurahContent(verses) {
    const contentContainer = document.getElementById('quran-content');
    contentContainer.innerHTML = '';
    
    verses.forEach(verse => {
        const verseItem = document.createElement('p');
        verseItem.classList.add('verse');
        verseItem.textContent = `${verse.verse_key}: ${verse.text_uthmani}`;
        contentContainer.appendChild(verseItem);
    });
}

// تحميل البيانات عند تشغيل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    fetchSurahList();
});


// وظيفة البحث داخل السور
function searchInSurah() {
    let query = document.getElementById("search-input").value.toLowerCase();
    let ayahs = document.getElementById("surah-content").innerText.split("\n");

    let results = ayahs.filter(ayah => ayah.toLowerCase().includes(query));

    document.getElementById("search-results").innerHTML = results.length > 0 ? results.join("<br>") : "لم يتم العثور على نتائج.";
}

// إضافة مستمع للبحث
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("search-button").addEventListener("click", searchInSurah);
});
